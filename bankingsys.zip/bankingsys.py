from abc import ABC, abstractmethod

class BankAccount(ABC):
    def __init__(self, name, balance):
        self.name = name
        self._balance = balance

    def deposit(self, amount):
        self._balance += amount

    def balance(self):
        return self._balance

    @abstractmethod
    def withdraw(self, amount):
        pass

    @abstractmethod
    def interest(self):
        pass

class SavingsAccount(BankAccount):

    def withdraw(self, amount):
        if self._balance - amount >= 1000:
            self._balance -= amount
            print("Savings withdrawal successful")
        else:
            print("Minimum balance required")

    def interest(self):
        return self._balance * 0.05

class CurrentAccount(BankAccount):

    def withdraw(self, amount):
        if self._balance >= amount + 100:
            self._balance -= amount + 100
            print("Current withdrawal successful")
        else:
            print("Insufficient balance")

    def interest(self):
        return 0

class FixedDepositAccount(BankAccount):

    def withdraw(self, amount):
        print("Withdrawal not allowed")

    def interest(self):
        return self._balance * 0.08


accounts = [
    SavingsAccount("Kamal", 50000),
    CurrentAccount("Nimal", 75000),
    FixedDepositAccount("Amal", 100000)
]

for account in accounts:
    account.deposit(5000)
    account.withdraw(2000)

    print(
        account.name,
        "Balance =", account.balance(),
        "Interest =", account.interest()
    )
