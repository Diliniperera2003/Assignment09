from abc import ABC, abstractmethod

class Course(ABC):

    def __init__(self, student, marks):
        self.student = student
        self._marks = marks

    @abstractmethod
    def final_result(self):
        pass

    def summary(self):
        print(
            self.student,
            "Final Result =",
            self.final_result()
        )
class ProgrammingCourse(Course):

    def final_result(self):
        quiz = self._marks["quiz"]
        assignment = self._marks["assignment"]
        exam = self._marks["exam"]

        return quiz * 0.2 + assignment * 0.3 + exam * 0.5

class LaboratoryCourse(Course):

    def final_result(self):
        practical = self._marks["practical"]
        assignment = self._marks["assignment"]
        exam = self._marks["exam"]

        return practical * 0.4 + assignment * 0.2 + exam * 0.4

class ResearchCourse(Course):

    def final_result(self):
        report = self._marks["report"]
        presentation = self._marks["presentation"]
        project = self._marks["project"]

        return report * 0.4 + presentation * 0.2 + project * 0.4

courses = [

    ProgrammingCourse(
        "Kamal",
        {
            "quiz": 80,
            "assignment": 75,
            "exam": 85
        }
    ),

    LaboratoryCourse(
        "Nimal",
        {
            "practical": 90,
            "assignment": 80,
            "exam": 70
        }
    ),

    ResearchCourse(
        "Amal",
        {
            "report": 85,
            "presentation": 80,
            "project": 90
        }
    )
]
for course in courses:
    course.summary()
